REDFIN_URL="https://www.redfin.com{}"
REDFIN_ZIP_URL="/zipcode/{zip_code}"
REDFIN_FILTER_URL="/filter/include=sold-{sale_period}"

REDFIN_API_CLASS_DEF=("a",{"class":"downloadLink"})
REDFIN_API_CLASS_ID='href'


ZIP_DATASET_URL="https://www.unitedstateszipcodes.org{}"
CONST_ZD_URL_EXTENSION="/zip-code-database/#"


DEFAULT_TUNER_VARIABLE=1.5


CONFIG='config.json'