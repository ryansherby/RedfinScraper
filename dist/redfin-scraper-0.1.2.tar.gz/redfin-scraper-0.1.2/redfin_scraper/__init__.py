from redfin_scraper import config
from redfin_scraper.core.redfin_scraper import RedfinScraper


__version__='0.1.1'